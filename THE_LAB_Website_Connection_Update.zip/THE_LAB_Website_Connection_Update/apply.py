import hashlib,json,pathlib,sys
package=pathlib.Path(__file__).resolve().parent
if len(sys.argv)!=2: raise SystemExit("Usage: python3 apply.py /path/to/the-lab")
repo=pathlib.Path(sys.argv[1]).resolve()
if not (repo/"companion/package.json").is_file(): raise SystemExit("This is not THE LAB repository root.")
manifest=json.loads((package/"manifest.json").read_text())
changes=[]
for name,expected in manifest.items():
    target=repo/name
    source=package/"files"/name
    if not target.resolve().is_relative_to(repo): raise SystemExit("Unsafe path")
    content=source.read_bytes()
    if target.exists() and target.read_bytes()==content: continue
    current=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    if current not in (expected if isinstance(expected,list) else [expected]): raise SystemExit("Source changed: "+name+". Merge this update with the newer file. No files written.")
    changes.append((target,content))
for target,content in changes:
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(content)
print("Applied",len(changes),"files. Review, test and commit to deploy. No database was changed.")

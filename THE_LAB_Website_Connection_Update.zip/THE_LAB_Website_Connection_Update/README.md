# THE LAB — website connection update

This package combines connected website coaching and the app player profile on the main Profile screen. It also retains Profile → Website connection for managing the link. The website side is deployed separately. It supports shared website notes, approved training focus, athlete reflections back to the website, and coach replies. It does not merge databases or synchronize events.

## Apply to the correct repository

Repository: TP4L/the-lab
Branch: claude/ainwiththelab-companion-app-a19xu2
Based on the uploaded source snapshot associated with Render commit b8290b3.

1. Download a fresh app backup from Admin → System.
2. Extract this package outside your repository checkout.
3. Run `python3 /path/to/this-package/apply.py /path/to/the-lab`.
   The script checks ALL affected files against the original snapshot or the previous connection update before writing. It stops if anything changed, so newer work is not overwritten. It does not commit or deploy.
4. Run `cd companion` and `npm test` (Node 22.13+).
5. Review and commit the eight changed/new files to the Render-connected branch. Confirm Render deploys that commit successfully.
6. Open the app and refresh. Profile should show connected website coaching above the app development details and history.

If you are using another coding assistant, give it this whole package and ask it to review/apply these changes to the branch above. If original-file checks fail, merge changes into the newer code rather than bypassing the checks.

## Member connection

1. On the website: Member home → Connect website profile.
2. Sign in to the approved website account with a claimed athlete profile.
3. Create a connection code (10-minute, single-use; new codes revoke old connections).
4. In the app: sign in to your own account → Profile → Website connection → paste the code → Connect.
5. Shared notes and approved focus refresh every 30 seconds while Profile or Website connection is visible. Reflections submitted here appear in the website development workspace; coach feedback returns here.
6. Disconnect from either side to revoke future access. Connection credentials expire after 90 days; reconnect then.

No new environment variables or API keys are required. The additive migration creates website_connections. Keep the existing persistent /data disk and database. Do not replace lab.db with the uploaded backup. No database, passwords, user data, or credentials are included in this package.

## Verification

48 existing companion tests passed, plus a new companion connection test. Two-server integration tests on the website side passed: code expiration/replay, origin/auth checks, private-note/draft exclusion, athlete isolation, reflection idempotency/conflicts, coach feedback, membership revocation, changed profile mapping and disconnect. Seven existing website development integration groups passed.

Production account linking is not verified until this Render update is deployed and a claimed member completes the flow. The updated package passes all 49 companion tests and JavaScript syntax validation. Browser UI checks could not run because this environment has no Chromium executable. Website notes remain authoritative. App details, coaching notes, reflections, photos and session results are preserved and labeled separately in the same profile. This is a combined view, not a destructive record merge, shared login, or bidirectional sync of every field. App reflections stay in the app; the website reflection form sends to the website coach. Linking requires a one-time code and never matches people by name.
